const defaultTheme = () => {
   alert('switch to default theme');
};

const oceanTheme = () => {
   alert('switch to ocean theme');
};

const desertTheme = () => {
   alert('switch to desert theme');
};

/*
document.querySelector(???).onclick = defaultTheme;
document.querySelector(???).onclick = oceanTheme;
document.querySelector(???).onclick = desertTheme;
*/
